<?php
/*
 *  Mail : subinpvasu@gmail.com
 *  Skype : subinpvasu 
 *  AdWords API integration
 */
 
class Credentials{
    public static $MASTER_ID = '6076703147';    
    public static $CLIENT_ID = '435665370423-3ivpqn0m184a3im0o11hrre66u6i7vbp.apps.googleusercontent.com';
    public static $CLIENT_SECRET = '4xOFo_u7CqB2LF31mFAPD4PM';
    public static $DEVELOPER_TOKEN = '164oteZ_x-t9PxaFy1Mikg';
    public static $REFRESH_TOKEN = '1//0fcoTrbo4yJpWCgYIARAAGA8SNwF-L9Irq54YVfPKG-LlnexL6Fq7hmYL7esa1UKspA5aMEoFSNh631WnPyX-xUCDGxDxJGYVNmI';
    public static $STATUS_FIELD = 16;
    public static $PAGE_LIMIT = 500;
    public static $REDIRECT_URI = 'http://saffronsunenergy.com/js/sasing/oauth/index.php';
    public static $AUTHORIZATION_URI = 'https://accounts.google.com/o/oauth2/v2/auth';
    public static $TOKEN_CREDENTIAL_URI = 'https://oauth2.googleapis.com/token';
    public static $SCOPE = 'https://www.googleapis.com/auth/adwords';
 
            
}
