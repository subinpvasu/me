<?php
/* 
 *  Mail : subinpvasu@gmail.com
 *  Skype : subinpvasu 
 *  Author : SUBIN P VASU, Freelance Google AdWords API Developer - PHP
 *  Created On : 18 Feb, 2020 
 */


class Credentials{
    //public static $MASTER_ID = '9551381797';
    //public static $CLIENT_ID = '816983496606-0er9pinrt8j9fvhd76joff2cd2t7l10g.apps.googleusercontent.com';
    //public static $CLIENT_SECRET = 'Ymh5veDe7gx-8s40Mk1ONj3W';
    //public static $DEVELOPER_TOKEN = '164oteZ_x-t9PxaFy1Mikg';
    //public static $REFRESH_TOKEN = '1//0g--Kfp77WU_5CgYIARAAGBASNwF-L9Irf8xFk0tJHPq3HkvrKIZ_tkJOXSrJ6evy6JHnCCQUNCxat54WTomT_go9VYOeHZg1Ios';
    public static $MASTER_ID = '8168051711';
    public static $CLIENT_ID = '96905153207-iq7fjce0car4igll19h65dofvmqto5tc.apps.googleusercontent.com';
    public static $CLIENT_SECRET = 'J3xyHEno3KRUnl2dDMWkiAeP';
    public static $REFRESH_TOKEN = '1//0gXy3Yr-sUhSCCgYIARAAGBASNwF-L9IrpW96XZR3AltKSSObu3VewBZ_wIu0FA4668-eoLOGVpAWA5cngWmgiES4SDFmFdEME6I';
    public static $DEVELOPER_TOKEN = 'WJjsdUkGHeAn8poHHkuDpQ';    
    public static $STATUS_FIELD = 16;
    public static $PAGE_LIMIT = 500;            
    public static $MULTIPLIER = 1000000;            
}

